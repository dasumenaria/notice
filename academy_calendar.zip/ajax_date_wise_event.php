<?php
include('database.php');
$date_wise_event_id=$_GET['date_wise_event_id'];
//exit;
?>
<div>	<table class="table table-bordered table-hover" id="sample_1">
 
								<thead>
								<tr style="background-color:#FFFFFF; color:#1A0DB3;background:#f9f9f9;">
									<td>
										 #
									</td>
									<td>
										<label class="contrl-label">Event Title</label>
									</td>
									<td>
										<label class="contrl-label">Date from</label>
									</td>
										<td>
										<label class="contrl-label">Date To</label>
									</td>
									<td>
                                        <label class="contrl-label">Location</label>
									</td>
									<td>
                                        <label class="contrl-label">Action</label>
									</td>
								</tr>
								</thead>
							  <?php
			  $r1=mysql_query("select * from event where flag='0' order by id Desc ");		
					$i=0;
					while($row1=mysql_fetch_array($r1))
					{
					$i++;
					$id=$row1['id'];
					$title=$row1['title'];
                    $description=$row1['description'];
					$date_from=$row1['date_from'];
					$from=date('d-m-Y', strtotime($date_from));
					$date_to=$row1['date_to'];
					$to=date('d-m-Y', strtotime($date_to));
					$location=$row1['location'];
                    $image=$row1['image'];
					$role_id=$row1['role_id'];
					$r2=mysql_query("select * from master_role where id='".$role_id."'");		
					$fet=mysql_fetch_array($r2);
					$role_name=$fet['role_name'];
		            $event_date11=str_replace('-', '', $date_from);
					$exact_trim=$event_date11;
					$datetime = DateTime::createFromFormat('Ymd', $exact_trim);
$ems=$datetime->format('m');
					if($ems==$date_wise_event_id){
					
					?>
					
								<tbody>
								<tr>
									<td>
							<?php echo $i;?>
									</td>
									<td>
									<?php echo $title;?>
									</td>
									<td>
									<?php echo $from;?>
									</td>
                                    <td>
									<?php echo $to;?>
									</td>
									 <td>
									<?php echo $location;?>
									</td>
									<td>
									 <a class="btn btn-circle btn-xs" style="color:#03F; background-color:#EEEEEE" data-toggle="modal" href="#view<?php echo $id ;?>" style="color: white">
										<i class="fa fa-search"></i></a>
										
										  <div class="modal fade" id="view<?php echo $id ;?>" tabindex="-1" aria-hidden="true" style="padding-top:35px">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-footer">
                     <table class="table-condensed table-bordered" width="100%">
					 <tr style="background-color:#FFFFFF; color:#1A0DB3">
									<td>
										 #
									</td>
									<td>
										<label class="contrl-label">Event Name</label>
									</td>
									<td>
										<label class="contrl-label">Date</label>
									</td>
										<td>
										<label class="contrl-label">Time</label>
									</td>
									</tr>
					  <?php
			  $event_details=mysql_query("select * from event_details where event_id='".$id."' order by id Desc");		
					$l=0;
					while($event_details1=mysql_fetch_array($event_details))
					{
					$l++;
					$e_id=$event_details1['id'];
					$name=$event_details1['name'];
                    $time=$event_details1['time'];
					$date=$event_details1['date'];
					$x_date=date('d-m-Y', strtotime($date));
					
					?>
					
								<tbody>
								<tr>
									<td>
							<?php echo $l;?>
									</td>
									<td>
									<?php echo $name;?>
									</td>
									<td>
									<?php echo $x_date;?>
									</td>
                                    <td>
									<?php echo $time;?>
									</td>
									</tr></tbody>
					 
					<?php }?>
					 </table>
					 
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <!-- /.modal-dialog -->
            </div>
										
										
							
									   
									   
									   
									</td>
								</tr>
								</tbody>
                    <?php }} ?>
								</table>
							</div>
									

		 
							
				