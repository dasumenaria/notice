<?php
 include("index_layout.php");
 include("database.php");
 $user=$_SESSION['category'];
 
 if(isset($_POST['sub_del']))
{
  $delet_student=$_POST['delet_student'];
   $r=mysql_query("update `student` SET `flag`='1' where id='$delet_student'" );
    $sql=mysql_query($r);
  }

  ?> 
<html>
<head>
<?php css();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<?php contant_start(); menu();  ?>
<body>
	<div class="page-content-wrapper">
		 <div class="page-content">
			
			
			<div class="portlet box">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-gift"></i> View Profile
							</div>
							
						</div>
						<div class="portlet-body form">
								<div class="form-body scroller" style="height:500px;"  data-always-visible="1" data-rail-visible="0">
								 <div class="table-scrollable">
								<table class="table table-bordered" id="mytbl">
								<thead>
								<tr><td style="align:left; font-size:15px"><i class="fa fa-search">&nbsp;Search by Enrollment/Scholar No:</i></td><td  colspan="8" style="align:right;"> <input class="form-control input-medium"  type="text" id="search">
					</td>
					</tr>
								<tr style="background-color:#EEEEEE; color:#000">
									<td>
										 #
									</td>
									<td>
										Student Name
									</td>
									<td>
										 Enrollment No.
									</td>
                                  
									<td>
                                        Action
									</td>
								</tr>
								</thead>
							 <?php
			  $r1=mysql_query("select * from student where flag='0' order by id Asc ");		
					$i=0;
					while($row1=mysql_fetch_array($r1))
					{
					$i++;
					$id=$row1['id'];
					$name=$row1['name'];
                    $eno=$row1['eno'];
					$user_image=$row1['user_image'];
					
					   $father_name=$row1['father_name'];
                            $mother_name=$row1['mother_name'];
                            $dept=$row1['dept'];
                            $semester=$row1['semester'];
                            $year=$row1['year'];
                            $hostel=$row1['hostel'];
                            $mobile_no=$row1['mobile_no'];
                            $dob=$row1['dob'];
					?>
                 			<tbody>
								<tr>
									<td>
							<?php echo $i;?>
									</td>
									<td class="search">
									<?php echo $name;?>
									</td>
                                    <td>
									<?php echo $eno;?>
									</td>
									
									
									
                                    <td>
                                              <a class="btn btn-circle btn-xs" style="color:#44B6AE; background-color:#EEEEEE"  rel="tooltip" title="Delete"  data-toggle="modal" href="#delete1<?php echo $id ;?>"><i class="fa fa-search"></i></a>

										
										 <div class="modal fade" id="delete1<?php echo $id ;?>" tabindex="-1" aria-hidden="true" style="padding-top:35px">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <span class="modal-title" style="font-size:14px; text-align:left"><b>Profile</b></span>
                        </div>
                        <div class="modal-footer">


							<div class="portlet-body">
							<div class="tab-content">
						    
<div class="row">
                    <div class="col-sm-4">
                 <center>   <img src="user/<?php echo $user_image;?>" width="180px" height="180px"></center>
                    </div>             
                    <div class="col-sm-8">
                         <br/>
                        <div class="row">
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Name</p><h4 style="color:#f3565d;" ><?php echo $name; ?></h4></div>
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Enrollment</p><h4 style="color:#f3565d;" ><?php echo $eno; ?></h4></div>
                        </div>
                        <br/><br/>
                        <div class="row">
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Father Name</p><h4 style="color:#f3565d;" ><?php echo $father_name; ?></h4></div>
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Mother Name</p><h4 style="color:#f3565d;" ><?php echo $mother_name; ?></h4></div>
                        </div>
                    </div>             
</div>
<br/>
<div class="row">
                    <div class="col-sm-4">
    <center><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">   Date-Of-Birth<h4 style="color:#f3565d;" ><?php echo $dob; ?></p></h4></center>
                    </div>             
                    <div class="col-sm-8">
      
                        <div class="row">
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Branch</p><h4 style="color:#f3565d;" ><?php echo $dept; ?></h4></div>
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Semester</p><h4 style="color:#f3565d;" ><?php echo $semester; ?></h4></div>
                        </div>
                        <br/>
                        <div class="row">
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Year</p><h4 style="color:#f3565d;" ><?php echo $year; ?></h4></div>
                        <div class="col-sm-4"><p style="color:#5c9bd1;font-weight:bold;font-size:11pt;">Mobile No</p><h4 style="color:#f3565d;" ><?php echo $mobile_no; ?></h4></div>
                        </div>
                    </div>             
</div>             
</div>
                                  

    </div>
							
							
							
							
							
                        </div>
                    </div>
                </div>
            </div>
										
										
										
                                        &nbsp;
                                        
                                        <a class="btn btn-circle btn-xs" style="color:#03F; background-color:#EEEEEE" href="edit_profile.php?id=<?php echo $id;?>" style="color: white">
										<i class="fa fa-edit"></i></a>
                                        &nbsp;
										
            <a class="btn btn-circle btn-xs" style="color:#ED1C24; background-color:#EEEEEE"  rel="tooltip" title="Delete"  data-toggle="modal" href="#delete<?php echo $id ;?>"><i class="fa fa-trash"></i></a>
            <div class="modal fade" id="delete<?php echo $id ;?>" tabindex="-1" aria-hidden="true" style="padding-top:35px">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <span class="modal-title" style="font-size:14px; text-align:left">Are you sure, you want to delete this student?</span>
                        </div>
                        <div class="modal-footer">
                        <form method="post" name="delete<?php echo $id ;?>">
                            <input type="hidden" name="delet_student" value="<?php echo $id; ?>" />
                            
                            <button type="submit" name="sub_del" value="" class="btn btn-sm red-sunglo ">Yes</button> 
                        </form>
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <!-- /.modal-dialog -->
            </div>
									   
									   
									   
									</td>
								</tr>
								</tbody>
                    <?php } ?>
								</table>
							</div>
									</div>
						</div>
					</div>
			
			
			</div></div>
</body>

<?php footer();?>
<script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>

<script>
$(document).ready(function(){
	$('#search').keyup(function() 
	{
		var $rows = $('#mytbl tbody tr');
		var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
		$rows.show().filter(function() {
			var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
			return !~text.indexOf(val);
		}).hide();
	});
	});
	</script>
<?php scripts();?>

</html>


