<?php
 include("index_layout.php");
 include("database.php");
 $user=$_SESSION['category'];
 
 if(isset($_POST['sub_del']))
{
  $delet_model=$_POST['delet_model'];
   $r=mysql_query("update `academy_calendar` SET `flag`='1' where id='$delet_model'" );
    $sql=mysql_query($r);
  }
?>
<?php  
$message=""; 
if(isset($_POST['sub_edit']))
{
$edit=$_REQUEST['edit_id'];  
$name=mysql_real_escape_string($_REQUEST["name"]);
@$type=mysql_real_escape_string($_REQUEST["type"]);
$date1=mysql_real_escape_string($_REQUEST["date"]);
$date=date('Y-m-d',strtotime($date1));
$r=mysql_query("update `academy_calendar` SET `name`='$name',`type`='$type',`date`='$date' where id='$edit'" );
$sql=mysql_query($r);
$r=mysql_query($sql);
$message = "Calendar Update Successfully";
 
}
else
{
  
	echo mysql_error();
}  
  


  ?> 
<html>
<head>
<?php css();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<?php contant_start(); menu();  ?>
<body>
	<div class="page-content-wrapper">
		 <div class="page-content">
			
			
			<div class="portlet box">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-gift"></i> View Academic Calendar
							</div>
							<!--<div class="tools">
							<a class="" href="create_news.php" style="color: white"><i class="fa fa-search">Add New Academy Event</i></a>
							&nbsp;
								<a href="" class="collapse" data-original-title="" title="">
								</a>
								
							</div>-->
						</div>
						<div class="portlet-body form">
                                                </br></br>
						<?php if($message!="") { ?>
                       <!-- <input id="alert_message" type="text" class="form-control" value="some alert text goes here..." placeholder="enter a text ...">-->
<div class="message" style="margin-left:290px;color:#bbdba1;font-size:11pt;font-weight:bold;" ><?php echo $message; ?></div>
</br>
<?php } ?>
							<form class="form-horizontal" role="form" id="noticeform" method="post" enctype="multipart/form-data">
								<div class="form-body scroller" style="height:500px;"  data-always-visible="1" data-rail-visible="0">

								 <div class="table-striped table-condensed table-bordered table-hover ">
								<table class="table table-bordered" id="mytbl">
								<thead>
								<tr><td style="align:left;">&nbsp;Search by Title:</td><td  colspan="4" style="align:right;"> <input class="form-control input-medium"  type="text" id="search">
								</td>
							
								</tr>
								
								
								
								
								
								<tr style="background-color:#EEEEEE; color:#000">
									<td>
										 #
									</td>
									<td>
										Type
									</td>
									<td>
										 Title
									</td>
									<td>
                                      Calendar Date
									</td>
                                    <td>
                                        Action
									</td>
								</tr>
								</thead>
								<tbody id="view_data">
							 <?php
			  $r1=mysql_query("select * from acedmic_calendar where flag=0 ");		
					$i=0;
					while($row1=mysql_fetch_array($r1))
					{
					$i++;
					$id=$row1['id'];
					$type=$row1['type'];
                    $name=$row1['name'];
					$date=$row1['date'];
                    if($date=='0000-00-00')
									{	$date='';}
									else
									{ $date=date("d-m-Y", strtotime($date)); }

					?>

								<tr>
									<td>
							<?php echo $i;?>
									</td>
									<td>
									<?php echo $type;?>
									</td>
                                    <td class="search">
									<?php echo $name;?>
									</td>
                                    <td>
										 <?php echo $date;?>
									</td>
									<td>
                                                <a class="btn btn-circle btn-xs" style="color:#03F; background-color:#EEEEEE" rel="tooltip" title="Edit" data-toggle="modal" href="#edit<?php echo $id;?>"><i class="fa fa-edit"></i></a>
                                        <div class="modal fade" id="edit<?php echo $id ;?>" tabindex="-1" aria-hidden="true" style="padding-top:35px">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                           <div class="portlet-body form">
							<form class="form-horizontal" role="form" id="noticeform" method="post" enctype="multipart/form-data">
							
							
                                <input type="hidden" name='edit_id' class="form-control" value="<?php echo $id;?>" >	
							
								<div class="form-body">
									<div class="form-group">
                                                        <label class="col-md-3 control-label">Select Type</label>
                                                        <div class="col-md-3">
                                                        <select name="type" required class="form-control select select2 select2me">
                                                        <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
                                                        <option value="holiday">Holiday</option>
                                                         <option value="event">Event</option>
                                                         <option value="festival">Festival</option>
                                                        <select/>
                                                        </div>
                                                        </div>
									<div class="form-group">
										<label class="col-md-3 control-label">Name</label>
										<div class="col-md-3">
										<input class="form-control input-md" required placeholder="Name" type="text" name="name" value="<?php echo $name;?>">
                                    </div>
									</div>
                                    <div class="form-group">
										<label class="col-md-3 control-label">Date</label>
										<div class="col-md-3">
										<input class="form-control form-control-inline input-md date-picker" required id="field_5" value="<?php echo $date; ?>" placeholder="dd/mm/yyyy" type="text" data-date-format="dd-mm-yyyy" type="text" name="date">

										</div>
									</div>
                                <div class=" right1" align="right" style="margin-right:10px">
									<button type="submit" class="btn green" name="sub_edit">Update</button>
								</div>
							</form>
                    	</div>
					</div>
                        </div>
                   
                    </div>
                <!-- /.modal-content -->
                </div>
        <!-- /.modal-dialog -->
            </div>
                                        &nbsp;
                                       
									      <a class="btn btn-circle btn-xs" style="color:#ED1C24; background-color:#EEEEEE"
  rel="tooltip" title="Delete"  data-toggle="modal" href="#delete<?php echo $id ;?>"><i class="fa fa-trash"></i></a>
            <div class="modal fade" id="delete<?php echo $id ;?>" tabindex="-1" aria-hidden="true" style="padding-top:35px">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <span class="modal-title" style="font-size:14px; text-align:left">Are you sure, you want to delete this event?</span>
                        </div>
                        <div class="modal-footer">
                        <form method="post" name="delete<?php echo $id ;?>">
                            <input type="hidden" name="delet_model" value="<?php echo $id; ?>" />
                            
                            <button type="submit" name="sub_del" value="" class="btn btn-sm red-sunglo ">Yes</button> 
                        </form>
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <!-- /.modal-dialog -->
            </div>
									   
									   
									   
									</td>
								</tr>
								
                    <?php } ?>
					</tbody>
								</table>
							</div>
									</div>
							</form>
						</div>
					</div>
			
			
			</div></div>
</body>

<?php footer();?>
<script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>

<script>
$(document).ready(function(){
	$('#search').keyup(function() 
	{
		var $rows = $('#mytbl tbody tr');
		var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
		$rows.show().filter(function() {
			var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
			return !~text.indexOf(val);
		}).hide();
	});
	});
	</script>

<?php scripts();?>

</html>

