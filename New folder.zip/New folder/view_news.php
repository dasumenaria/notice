<?php
 include("index_layout.php");
 include("database.php");
 $user=$_SESSION['category'];
  $session_id=$_SESSION['id'];
 
 if(isset($_POST['sub_del']))
{
  $delet_model=$_POST['delet_model'];
   $r=mysql_query("update `news` SET `flag`='1' where id='$delet_model'" );
    $sql=mysql_query($r);
  }

  ?> 
<html>
<head>
<?php css();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<?php contant_start(); menu();  ?>
<body>
	<div class="page-content-wrapper">
		 <div class="page-content">
			
			
			<div class="portlet box">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-gift"></i> View News
							</div>
							<div class="tools">
							<a class="" href="create_news.php" style="color: white"><i class="fa fa-plus">Add New News</i></a>
							&nbsp;
								<!--<a href="" class="collapse" data-original-title="" title="">
								</a>-->
								
							</div>
						</div>
						<div class="portlet-body form" class="scroller" style="height:500px;">
							<form class="form-horizontal" role="form" id="noticeform" method="post" enctype="multipart/form-data">
								<div class="form-body scroller" style="height:500px;"  data-always-visible="1" data-rail-visible="0">
								 <div class="table-scrollable" >
								<table class="table-condensed table-bordered" id="mytbl" width="100%">
								<thead>
								<tr><td style="align:left;"><i class="fa fa-search">&nbsp;Search by Title:</i></td><td style="align:right;"> <input class="form-control input-medium"  type="text" id="search">
					</td><td colspan="6" align="right" ><a class="btn blue-madison" href="news_excel.php?id=<?php echo $session_id; ?>"><i class="fa  fa-file-excel-o">&nbsp; Excel</i></a></td>
					</tr>
								<tr style="background-color:#EEEEEE; color:#000">
									<td>
										 #
									</td>
									<td>
										News Title
									</td>
									<td>
										 News Details
									</td>
									<td>
										 Location
									</td>
									
                                    <td>
                                        News Date
									</td>
									<td>
                                        Action
									</td>
								</tr>
								</thead>
							 <?php
			  $r1=mysql_query("select * from news where flag='0' order by id Desc ");		
					$i=0;
					while($row1=mysql_fetch_array($r1))
					{
					$i++;
					$id=$row1['id'];
					$news_title=$row1['news_title'];
                    $news_details=$row1['news_details'];
					$news_date=$row1['news_date'];
                    $news_pic=$row1['news_pic'];
					$news_location=$row1['news_location'];
                    if($news_date=='0000-00-00')
									{	$news_date='';}
									else
									{ $news_date=date("d-m-Y", strtotime($news_date)); }

					?>

								<tbody>
								<tr>
									<td>
							<?php echo $i;?>
									</td>
									<td class="search">
									<?php echo $news_title;?>
									</td>
                                    <td>
									<?php echo $news_details;?>
									</td>
									 <td>
									<?php echo $news_location;?>
									</td>
                                    <!--<td>
									<image src="news/<?php echo $news_pic;?>" style="width:50px;height:50px;">
									</td>-->
									<td>	
										 <?php echo $news_date;?>
									</td>
									<td>
                                        <a class="btn btn-circle btn-xs" style="color:#03F; background-color:#EEEEEE" href="news_edit.php?id=<?php echo $id;?>" >
										<i class="fa fa-edit"></i></a>
                                        &nbsp;
                                       
									      <a class="btn btn-circle btn-xs" style="color:#ED1C24; background-color:#EEEEEE"  rel="tooltip" title="Delete"  data-toggle="modal" href="#delete<?php echo $id ;?>"><i class="fa fa-trash"></i></a>
            <div class="modal fade" id="delete<?php echo $id ;?>" tabindex="-1" aria-hidden="true" style="padding-top:35px">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <span class="modal-title" style="font-size:14px; text-align:left">Are you sure, you want to delete this event?</span>
                        </div>
                        <div class="modal-footer">
                        <form method="post" name="delete<?php echo $id ;?>">
                            <input type="hidden" name="delet_model" value="<?php echo $id; ?>" />
                            
                            <button type="submit" name="sub_del" value="" class="btn btn-sm red-sunglo ">Yes</button> 
                        </form>
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <!-- /.modal-dialog -->
            </div>
									   
									   
									   
									</td>
								</tr>
								</tbody>
                    <?php } ?>
								</table>
							</div>
									</div>
							</form>
						</div>
					</div>
			
			
			</div></div>
</body>

<?php footer();?>
<script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>

<script>
$(document).ready(function(){
	$('#search').keyup(function() 
	{
		var $rows = $('#mytbl tbody tr');
		var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
		$rows.show().filter(function() {
			var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
			return !~text.indexOf(val);
		}).hide();
	});
	});
	</script>
<?php scripts();?>
</html>
