<?php
// Database parameters
$hostname = "localhost";
$db_user = "root";
$db_password = "";
$databasename = "vinayakam";

 
define("ROOT_WWW", "http://phppoets.com/notice/");

$site_url = "http://phppoets.com/notice/";


?>
