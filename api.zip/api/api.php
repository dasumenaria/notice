<?php
require_once("Rest.inc.php");
date_default_timezone_set('asia/kolkata');
ini_set("expose_php",0);
class API extends REST {

    public $data = "";
    
    const DB_SERVER = "localhost";
    const DB_USER = "phppoets_notice";
    const DB_PASSWORD = ",Jr@qc5#,5&C";
    const DB = "phppoets_notice";
	


    private $db = NULL;
    public function __construct() {
    parent::__construct();  // Init parent constructor
    $this->dbConnect();    // Initiate Database connection     
    }

    public function __destruct() {
    $this->db = NULL;
    }
    
    private function dbConnect() {
        // Set up the database
        try {            
            $this->db = new PDO('mysql:host=' . self::DB_SERVER . ';dbname=' . self::DB, self::DB_USER, self::DB_PASSWORD);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'ERROR: ' . $e->getMessage();
           /* $error = array('Type' => 'Error', "Error" => 'Some Error From Server', 'Responce' => "");
            $this->response($this->json($error), 251);*/
        }
    }
     /*
     * Public method for access api.
     * This method dynmically call the method based on the query string
     *
     */
    public function processApi(){
    $func = strtolower(trim(str_replace("/", "", $_REQUEST['rquest'])));
	if ((int) method_exists($this, $func) > 0){
    $this->$func();
		   }
    else{
    $this->response('', 404);  
	//If the method not exist with in this class, response would be "Page not found".
		}	
        //,Jr@qc5#,5&C
                                }
////////////My API FUN///////////////////////////////
public function login() {
global $link;
		include_once("common/global.inc.php");
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
        
//$url="http://phppoets.com/notice/api/login";
//print_r(get_headers($url));
//exit;
        $enrollment_no=$this->_request['enrollment_no'];
		$password=$this->_request['password'];
        
		$enrollment_no_input=0;
		$password_input=0;
		if(isset($this->_request['enrollment_no']))
		{
			$enrollment_no = $this->_request['enrollment_no'];
			$enrollment_no_input=1;
		}
		if(isset($this->_request['password']))
		{
			$password = $this->_request['password'];
			 $password_input=1;
			 $newpassword=md5($password);
		}
		if($password_input==1 && $enrollment_no_input==1)
		{
		
		$sql = $this->db->prepare("SELECT * FROM login WHERE enrollment_no=:enrollment_no AND password=:password");
		$sql->bindParam(":enrollment_no", $enrollment_no, PDO::PARAM_STR);
			$sql->bindParam(":password", $newpassword, PDO::PARAM_STR);
			 $sql->execute();
			 
				if($sql->rowCount()>0)
			{


$about_sql = $this->db->prepare("SELECT * FROM about_us");
		$about_sql->execute();
		$about_sql1 = $about_sql->fetch(PDO::FETCH_ASSOC);
		$x_about_us=$about_sql1['about_us'];


			$sql = $this->db->prepare("SELECT * FROM login WHERE enrollment_no=:enrollment_no AND password=:password");
			$sql->bindParam(":enrollment_no", $enrollment_no, PDO::PARAM_STR);
			$sql->bindParam(":password", $newpassword, PDO::PARAM_STR);
			$sql->execute();			
			$row_login = $sql->fetch(PDO::FETCH_ASSOC);

if(!empty($row_login ['user_image'])){
						 $row_login ['user_image'] = $site_url."user/".$row_login ['user_image'];
					}else{
						 $row_login ['user_image'] = "";
					}

			$result = array('id' => $row_login['id'],
					'enrollment_no' => $row_login['enrollment_no'],
'username' => $row_login['name'],
'userimage' => $row_login['user_image'],
'uniq_id' => $row_login['school_id'],
'about_us' => $x_about_us
					);
			//$result1 = array("login" => $result );
			$success = array('status'=> true, "Error" => "login successful",'login' => $result  );
			$this->response($this->json($success), 200);
		}    
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
}

////////////////////////
public function push_token_update() {
		global $link;
		include_once("common/global.inc.php");
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		$device_token=$this->_request['device_token'];
		$id=$this->_request['id'];
		
		$sql = $this->db->prepare("SELECT * FROM login WHERE id=:id");
		$sql->bindParam(":id", $id, PDO::PARAM_STR);
			$sql->execute();
			if($sql->rowCount()>0)
			{
			$sql_update_token = $this->db->prepare("UPDATE `login` SET device_token='".$device_token."' WHERE id='".$id."' LIMIT 1;");
			$sql_update_token->execute();

                $success = array('status' => true, "msg" => 'Yes', 'Responce' => '');
                $this->response($this->json($success), 200);
            } else {
                $error = array('status' => false, "Error" => "No", 'Responce' => '');
                $this->response($this->json($error), 200);
            }
	}

//home page api


public function notification() {
	global $link;
		include_once("common/global.inc.php");

		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
    
		$sql = $this->db->prepare("SELECT * FROM noticedetail order by id DESC");
		$sql->execute();
			 
				if($sql->rowCount()>0)
			{
			$row_notification1 = $sql->fetchALL(PDO::FETCH_ASSOC);
            
            foreach($row_notification1 as $row_notification)
            {
				
					$timestamp=$row_notification['dateofpublish'];
$dt=str_replace('-', '', $timestamp);
$event_time=$row_notification['time'];
$newDateTime = date('h:i', strtotime($event_time));
$npm = date('A', strtotime($event_time));
$tm=str_replace(':', '', $newDateTime);
$exact_trim=$dt.$tm;
$datetime = DateTime::createFromFormat('YmdHi', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');
$eh=$datetime->format('H');
$ei=$datetime->format('i');
$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'year' => $ey,
'H' => $eh,
'I' => $ei,
'A' => $npm);
				 if(!empty($row_notification['notice_file'])){
						 $row_notification['notice_file'] = $site_url."uploads/".$row_notification['notice_file'];
					}else{
						 $row_notification['notice_file'] = "";
					}
				
			$result[] = array('id' => $row_notification['id'],
					'title' => $row_notification['title'],
                    'dateofpublish' => $row_notification['dateofpublish'],
                    'time'=> $row_notification['time'],
					'date_time'=> $date_time,
'notice_no'=> $row_notification['notice_no'],
'pdf_file'=> $row_notification['notice_file']

					);
            }
			//$result1 = array("login" => $result );
			$success = array('status'=> true, "Error" => "your notification",'notification' => $result);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}

///

public function notification_details() {
	global $link;
		include_once("common/global.inc.php");

		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
    		$notice_id=$this->_request['notice_id'];

		$sql = $this->db->prepare("SELECT * FROM noticedetail where id='".$notice_id."' ");
		$sql->execute();
			 
				if($sql->rowCount()>0)
			{
			$row_notification = $sql->fetch(PDO::FETCH_ASSOC);
            
					$timestamp=$row_notification['dateofpublish'];
$dt=str_replace('-', '', $timestamp);
$event_time=$row_notification['time'];
$newDateTime = date('h:i', strtotime($event_time));
$npm = date('A', strtotime($event_time));
$tm=str_replace(':', '', $newDateTime);
$exact_trim=$dt.$tm;
$datetime = DateTime::createFromFormat('YmdHi', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');
$eh=$datetime->format('H');
$ei=$datetime->format('i');
$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'year' => $ey,
'H' => $eh,
'I' => $ei,
'A' => $npm);
				 if(!empty($row_notification['notice_file'])){
						 $row_notification['notice_file'] = $site_url."notice/".$row_notification['notice_file'];
					}else{
						 $row_notification['notice_file'] = "";
					}
				
			$result = array('id' => $row_notification['id'],
					'title' => $row_notification['title'],
                    'dateofpublish' => $row_notification['dateofpublish'],
                    'time'=> $row_notification['time'],
					'date_time'=> $date_time,
'notice_no'=> $row_notification['notice_no'],
'pdf_file'=> $row_notification['notice_file']

					);
			$success = array('status'=> true, "Error" => "notification details",'notification_details' => $result);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "No data found.",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
//////////////////////////
 ////////////////this api is used for forget password//////////
public function user_forgot_password() 
	{
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		$mobile_no=$this->_request['mobile_no'];
			$check_mobile = $this->db->prepare("SELECT * FROM login WHERE mobile_no='".$mobile_no."'");
			$check_mobile->execute();
			if ($check_mobile->rowCount() > 0) {
		      $fetch_s_logins = $check_mobile->fetch(PDO::FETCH_ASSOC);
			  $s_id=$fetch_s_logins['id'];
             $otp=(string)mt_rand(1000,9999);
			 $sql_s=$this->db->prepare("UPDATE `login` SET otp='".$otp."' WHERE id='".$s_id."'");				                
			 $sql_s->execute();
			 
			
			 $sms=str_replace(' ', '+', 'Your one time OTP is: '.$otp.'');
			$working_key='A7a76ea72525fc05bbe9963267b48dd96';
				$sms_sender='JAINTE';	
				$sms=str_replace(' ', '+', $sms);
				file_get_contents('http://alerts.sinfini.com/api/web2sms.php?workingkey='.$working_key.'&sender='.$sms_sender.'&to='.$mobile_no.'&message='.$sms.'');
			 
			 $result1 = array("otp" => $otp);
			$success = array('Type' => "Successfully", "Error" => "Please enter your otp as a password.", 'Responce' => $result1);
				$this->response($this->json($success), 200);
			}
			else{
				$error = array('Type' => "Error", "Error" => "Mobile no did not find.", 'Responce' => '1');
				$this->response($this->json($error), 200);				
				} 	
		}
		////
		public function change_forgot_password() 
	{
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		$otp=$this->_request['otp'];
		$password=$this->_request['password'];
		$mobile_no=$this->_request['mobile_no'];
			$check_mobile = $this->db->prepare("SELECT * FROM login WHERE mobile_no='".$mobile_no."' AND otp='".$otp."'");
			$check_mobile->execute();
			if ($check_mobile->rowCount() > 0) {
			$fetch_s_logins = $check_mobile->fetch(PDO::FETCH_ASSOC);
			  $s_id=$fetch_s_logins['id'];
			$s_newpassword=md5($password);
			 $sql_s=$this->db->prepare("UPDATE `login` SET password='".$s_newpassword."', otp=0 WHERE id='".$s_id."'");
             
			 $sql_s->execute();
			$success = array('Type' => "Successfully", "Error" => "Password change successfully.", 'Responce' => '1');
				$this->response($this->json($success), 200);
			}
			else{
				$error = array('Type' => "Error", "Error" => "Please Check Your Otp.", 'Responce' => '1');
				$this->response($this->json($error), 200);				
				} 			
		}
//////////////////////////
public function notification_home() {
    include_once("common/global.inc.php");
        global $link;
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
$sql = $this->db->prepare("SELECT * FROM noticedetail order by noticenumber DESC");
		$sql->execute();        

							$fetch_qry1 = $sql->fetchALL(PDO::FETCH_ASSOC);
							
							if($sql->rowCount()>0)
							{
							
							foreach($fetch_qry1 as $fetch_qry){
							
                            $noticenumber=$fetch_qry['noticenumber'];
                            $x_notice='notice';
                            $y_notice='.pdf';
                            
                            $pdf_notice=$x_notice.$noticenumber.$y_notice;
                            
                            
							$branch=$fetch_qry['branch'];
                            $branch_data =explode(',', $branch);
                            $semester=$fetch_qry['semester'];
                            $semester_data =explode(',', $semester);
                            
                             $hostel=$fetch_qry['hostel'];
                            $hostel_data =explode(',', $hostel);
                            
                             $year=$fetch_qry['year'];
                            $year_data =explode(',', $year);
                            
                            if(!empty($fetch_qry['uploadfile'])){
						 $fetch_qry['uploadfile'] = $site_url."uploads/".$fetch_qry['uploadfile'];
					}else{
						 $fetch_qry['uploadfile'] = "";
					}
                    if(!empty($pdf_notice)){
						 $pdf_notice = $site_url."uploads/".$pdf_notice;
					}else{
						 $pdf_notice = "";
					}
                            
                           
                    foreach($branch_data as $branch_data1)
                    {
                      
                        $sql1 = $this->db->prepare("SELECT * FROM student where dept='".$branch_data1."'");
                        $sql1->execute();        
                            $fet_qrys = $sql1->fetchALL(PDO::FETCH_ASSOC);
                            foreach($fet_qrys as $d)
                            {
                                $id=$d['id'];
                                $a[]=$id;
                           
                            }
                    }
                     if(!empty($a))
                    {
                       $aa=$a; 
                    }
                    else{
                        $aa=[];
                    }
                     foreach($semester_data as $semester_data1)
                    {
                      
                        $sql2 = $this->db->prepare("SELECT * FROM student where semester='".$semester_data1."'");
                        $sql2->execute();        
                            $fet_qry1 = $sql2->fetchALL(PDO::FETCH_ASSOC);
                            foreach($fet_qry1 as $d)
                            {
                                $id=$d['id'];
                                $b[]=$id;
                           
                            }
                    }
                     if(!empty($b))
                    {
                       $bb=$b; 
                    }
                    else{
                        $bb=[];
                    }
                    foreach($hostel_data as $hostel_data1)
                    {
                        $sql3 = $this->db->prepare("SELECT * FROM student where hostel='".$hostel_data1."'");
                        $sql3->execute();        
                            $fet_qry2 = $sql3->fetchALL(PDO::FETCH_ASSOC);
                          
                            foreach($fet_qry2 as $cd)
                            {
                               $id=$cd['id'];
                                $c[]=$id;
                                
                            }
                    }
                    if(!empty($c))
                    {
                       $cc=$c; 
                    }
                    else{
                        $cc=[];
                    }
                    
                    foreach($year_data as $year_data1)
                    {
                        $sql4 = $this->db->prepare("SELECT * FROM student where year='".$year_data1."'");
                        $sql4->execute();        
                            $fet_qry3 = $sql4->fetchALL(PDO::FETCH_ASSOC);
                          
                            foreach($fet_qry3 as $y)
                            {
                               $id=$y['id'];
                                $cy[]=$id;
                                
                            }
                    }
                    if(!empty($cy))
                    {
                       $ccy=$cy; 
                    }
                    else{
                        $ccy=[];
                    }
                 
                 if(!empty($aa) && !empty($bb) && !empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($aa,$bb,$cc);
                 }
                 else if(!empty($aa) && !empty($bb) && empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($aa,$bb,$ccy);
                 }
                  else if(!empty($aa) && empty($bb) && !empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($aa,$cc,$ccy);
                 }
                 else if(empty($aa) && !empty($bb) && !empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($bb,$cc,$ccy);
                 }
                 else if(!empty($aa) && !empty($bb) && !empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($bb,$cc,$ccy);
                 }
                 else if(!empty($aa) && !empty($bb) && empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($aa,$bb);
                 }
                 else if(!empty($aa) && empty($bb) && empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($aa);
                 }
                  else if(empty($aa) && !empty($bb) && empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($bb);
                 }
                  else if(empty($aa) && empty($bb) && !empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($cc,$ccy);
                 }
                  else if(empty($aa) && empty($bb) && empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($ccy);
                 }
                  else if(empty($aa) && empty($bb) && !empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($cc);
                 }
                  else if(!empty($aa) && empty($bb) && !empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($aa,$cc);
                 }
                  else if(!empty($aa) && empty($bb) && empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($aa,$ccy);
                 }
                  else if(empty($aa) && !empty($bb) && !empty($cc) && empty($ccy))
                 {
                     $k=array_intersect($bb,$cc);
                 }
                  else if(empty($aa) && !empty($bb) && empty($cc) && !empty($ccy))
                 {
                     $k=array_intersect($bb,$ccy);
                 }
                
                 
            if(!empty($k))
			{
            
            foreach($k as $row_notification)
            {
                 $sql9 = $this->db->prepare("SELECT * FROM student where id='".$row_notification."'");
                        $sql9->execute();        
                            $fet_qryn = $sql9->fetch(PDO::FETCH_ASSOC);
                            
                          
                          
			$result[] = array('id' => $fetch_qry['noticenumber'],
            'eno' => $fet_qryn['eno'],
					'title' => $fetch_qry['title'],
                    'dateofpublish' => $fetch_qry['dateofpublish'],
                    'time'=> $fetch_qry['Time'],
                    'image'=>$fetch_qry['uploadfile'],
                    'pdf'=>$pdf_notice
					);
            }
			$success = array('status'=> true, "Error" => "your notification",'notification' => $result);
			$this->response($this->json($success), 200);
            }
			}
							}
			
			
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
        }
            			
        }
////////event//////////
public function event() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		        $limit=1;
$limit_start=$this->_request['start'];
$user_id=$this->_request['user_id'];

        $event_sql = $this->db->prepare("SELECT * FROM event where flag=0 order by id DESC LIMIT $limit_start , $limit ");
		$event_sql->execute();
				if($event_sql->rowCount()>0)
			{
			$event_fet = $event_sql->fetchALL(PDO::FETCH_ASSOC);
			foreach($event_fet as $row_event)
            {


$exist_sql = $this->db->prepare("SELECT * FROM add_to_calendar where user_id='".$user_id."' AND event_id='".$row_event['id']."'");
				$exist_sql->execute();
				$exist_sql1 = $exist_sql->fetch(PDO::FETCH_ASSOC);

				if($exist_sql->rowCount()>0)
				{
					$event_exist=true;
				}
				else{
					$event_exist=false;
				}


$event_sql_id = $this->db->prepare("SELECT * FROM gallery where event_id='".$row_event['id']."' AND type='1'");
$event_sql_id->execute();
$event_sql_id1 = $event_sql_id->fetch(PDO::FETCH_ASSOC);

if(!empty($event_sql_id1))
{
$event_sql_id2=$event_sql_id1['id'];
$isgallery=true;		
}
else{
$event_sql_id2='';
$isgallery=false;
}


				
				$timestamp=$row_event['event_date'];
$dt=str_replace('-', '', $timestamp);
$event_time=$row_event['event_time'];
$newDateTime = date('h:i', strtotime($event_time));
$npm = date('A', strtotime($event_time));
$tm=str_replace(':', '', $newDateTime);
$exact_trim=$dt.$tm;
$datetime = DateTime::createFromFormat('YmdHi', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$emm=$datetime->format('m');
$x_emm=$emm-1;
$ey=$datetime->format('Y');
$eh=$datetime->format('H');
$ei=$datetime->format('i');
$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'month_id' => $x_emm,
'year' => $ey,
'H' => $eh,
'I' => $ei,
'A' => $npm);
				
                if(!empty($row_event['event_pic'])){
						 $row_event['event_pic'] = $site_url."event/".$row_event['event_pic'];
					}else{
						 $row_event['event_pic'] = "";
					}
                
			$result[] = array('id' => $row_event['id'],
					'title' => $row_event['title'],
                    'discription' => $row_event['discription'],
					'details' => $row_event['details'],
                    'event_date'=> $row_event['event_date'],
                    'current_date'=> $row_event['curent_date'],
                    'event_pic'=>$row_event['event_pic'],
'gallery_id' => $event_sql_id2,
					'isgallery' => $isgallery,
					'event_time' => $row_event['event_time'],
					'location' => $row_event['location'],
					'date_time' => $date_time,
'event_tag' =>$event_exist
					
					);
            }
                             if(!empty($result))
				{
					 $kkr=$result;
				}
				else
				{
					$kkr=array();
				}

			$success = array('status'=> true, "Error" => "your Event",'event' => $kkr);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
		///




public function home_screen_api() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
				

				$user_id = $this->_request['user_id'];
        $home_sql = $this->db->prepare("SELECT * FROM home_gallery where flag=0 order by id ASC LIMIT 0 , 5");
		$home_sql->execute();
			if($home_sql->rowCount()>0)
			{
			$home_sql1 = $home_sql->fetchALL(PDO::FETCH_ASSOC);
			
			foreach($home_sql1 as $home_sql)
			{
			if(!empty($home_sql['pic'])){
						 $home_sql['pic'] = $site_url."home/".$home_sql['pic'];
					}else{
						 $home_sql['pic'] = "";
					}	
						
			$result3[]= array('id' => $home_sql['id'],
					'title' => $home_sql['title'],
                    'discription' => $home_sql['pic'],
					);	
}
			}
			else{
				$result3[] = array();
			}
			
		
				
				
				
        $event_sql = $this->db->prepare("SELECT * FROM event where flag=0 order by id DESC LIMIT 0 , 5");
		$event_sql->execute();
			if($event_sql->rowCount()>0)
			{
			$row_event1 = $event_sql->fetchALL(PDO::FETCH_ASSOC);
			
			foreach($row_event1 as $row_event)
			{
				$event_id=$row_event['id'];
				
				$event_sql_id = $this->db->prepare("SELECT * FROM gallery where event_id='".$event_id."' AND type='1'");
				$event_sql_id->execute();
				$event_sql_id1 = $event_sql_id->fetch(PDO::FETCH_ASSOC);

				if(!empty($event_sql_id1))
				{
				$event_sql_id2=$event_sql_id1['id'];
				$isgallery=true;		
				}
				else{
				$event_sql_id2='';
				$isgallery=false;
				}
				
$exist_sql = $this->db->prepare("SELECT * FROM add_to_calendar where user_id='".$user_id."' AND event_id='".$event_id."'");
				$exist_sql->execute();
				$exist_sql1 = $exist_sql->fetch(PDO::FETCH_ASSOC);
				
				if($exist_sql->rowCount()>0)
				{
					$event_exist=true;
				}
				else{
					$event_exist=false;
				}


			if(!empty($row_event['event_pic'])){
						 $row_event['event_pic'] = $site_url."event/".$row_event['event_pic'];
					}else{
						 $row_event['event_pic'] = "";
					}	
						$timestamp=$row_event['event_date'];
$dt=str_replace('-', '', $timestamp);
$event_time=$row_event['event_time'];
$newDateTime = date('h:i', strtotime($event_time));
$npm = date('A', strtotime($event_time));
$tm=str_replace(':', '', $newDateTime);
$exact_trim=$dt.$tm;
$datetime = DateTime::createFromFormat('YmdHi', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');
$eh=$datetime->format('H');
$ei=$datetime->format('i');

$emm=$datetime->format('m');
$x_emm=$emm-1;
$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'month_id' => $x_emm,
'year' => $ey,
'H' => $eh,
'I' => $ei,
'A' => $npm);
			   
			$result[]= array('id' => $row_event['id'],
					'title' => $row_event['title'],
                    'discription' => $row_event['discription'],
					'details' => $row_event['details'],
                    'event_date'=> $row_event['event_date'],
                    'current_date'=> $row_event['curent_date'],
                    'event_pic'=>$row_event['event_pic'],
					'event_time' => $row_event['event_time'],
					'gallery_id' => $event_sql_id2,
					'isgallery' => $isgallery,
					'location' => $row_event['location'],
					'date_time' => $date_time,
'event_tag' =>$event_exist
					
					);	
}
			}
			else{
				$result[] = array();
			}
		

        $news_sql = $this->db->prepare("SELECT * FROM news where flag=0 order by id DESC LIMIT 0 , 5 ");
		$news_sql->execute();
			if($news_sql->rowCount()>0)
			{
			$news_fsql = $news_sql->fetchALL(PDO::FETCH_ASSOC);
			foreach($news_fsql as $row_news)
            {
				
				
				$news_id=$row_news['news_id'];
				$nws_sql_id = $this->db->prepare("SELECT * FROM gallery where event_id='".$news_id."' AND type='2'");
				$nws_sql_id->execute();
				$nws_sql_id1 = $nws_sql_id->fetch(PDO::FETCH_ASSOC);
				if(!empty($nws_sql_id1))
				{
				$nws_sql_id2=$nws_sql_id1['id'];	
				}
				else{
				$nws_sql_id2='';
				}
				
                if(!empty($row_news['news_pic'])){
						 $row_news['news_pic'] = $site_url."news/".$row_news['news_pic'];
					}else{
						 $row_news['news_pic'] = "";
					}
					
					
$timestamp=$row_news['news_date'];
$dt=str_replace('-', '', $timestamp);
$exact_trim=$dt;
$datetime = DateTime::createFromFormat('Ymd', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');

$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'year' => $ey,
);
			$result1[] = array('id' => $row_news['id'],
					'news_title' => $row_news['news_title'],
					'news_sub_description'=>$row_news['news_sub_description'],
                    'news_details' => $row_news['news_details'],
                    'news_date'=> $row_news['news_date'],
					'gallery_id'=>$nws_sql_id2,
                    'news_pic'=>$row_news['news_pic'],
					'news_location'=>$row_news['news_location'],
					'date_time'=>$date_time
					
					);
					
   }
			}else{
				$result1[] = array();
			}



 $fg_sql = $this->db->prepare("SELECT * FROM sub_gallery order by id DESC LIMIT 0 , 4");
				$fg_sql->execute();
				$fcg_sql = $fg_sql->fetchALL(PDO::FETCH_ASSOC);
                $src= $fg_sql->rowCount();
				if($src>0)
				{
				foreach($fcg_sql as $row_gallery)
				{
                if(!empty($row_gallery['gallery_pic'])){
						 $row_gallery['gallery_pic'] = $site_url."gallery/".$row_gallery['gallery_pic'];
					}else{
						 $row_gallery['gallery_pic'] = "";
					}
                    $result6[] = array(
					'gallery' => $row_gallery['gallery_pic']
					);
                }
				}else{
				$result6[] = array();
			}
   
   
   $result2=array('slider' => $result3, 'events' => $result, 'news' => $result1, 'gallery' => $result6);
   
  $success = array('status'=> true, "Error" => "home screens",'responce' => $result2);
	$this->response($this->json($success), 200);   
  	

			}	

///
		
public function fetch_event() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		        $event_id=$this->_request['event_id'];
$user_id=$this->_request['user_id'];

				
				
		$event_sql_id = $this->db->prepare("SELECT * FROM gallery where event_id='".$event_id."' AND type='1'");
		$event_sql_id->execute();
		$event_sql_id1 = $event_sql_id->fetch(PDO::FETCH_ASSOC);

if(!empty($event_sql_id1))
		{
		$event_sql_id2=$event_sql_id1['id'];	
$isgallery=true;
		}
		else{
			$event_sql_id2='';
$isgallery=false;
		}

        $event_sql = $this->db->prepare("SELECT * FROM event where id='".$event_id."' ");
		$event_sql->execute();
			if($event_sql->rowCount()>0)
			{
			$row_event = $event_sql->fetch(PDO::FETCH_ASSOC);
                if(!empty($row_event['event_pic'])){
						 $row_event['event_pic'] = $site_url."event/".$row_event['event_pic'];
					}else{
						 $row_event['event_pic'] = "";
					}
					


$exist_sql = $this->db->prepare("SELECT * FROM add_to_calendar where user_id='".$user_id."' AND event_id='".$event_id."'");
				$exist_sql->execute();
				$exist_sql1 = $exist_sql->fetch(PDO::FETCH_ASSOC);
				
				if($exist_sql->rowCount()>0)
				{
					$event_exist=true;
				}
				else{
					$event_exist=false;
				}


					
						$timestamp=$row_event['event_date'];
$dt=str_replace('-', '', $timestamp);
$event_time=$row_event['event_time'];
$newDateTime = date('h:i', strtotime($event_time));
$npm = date('A', strtotime($event_time));
$tm=str_replace(':', '', $newDateTime);
$exact_trim=$dt.$tm;
$datetime = DateTime::createFromFormat('YmdHi', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$emm=$datetime->format('m');
$x_emm=$emm-1;
$ey=$datetime->format('Y');
$eh=$datetime->format('H');
$ei=$datetime->format('i');
$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'month_id' => $x_emm,
'year' => $ey,
'H' => $eh,
'I' => $ei,
'A' => $npm);
					
					
					
                
			$result= array('id' => $row_event['id'],
					'title' => $row_event['title'],
                    'discription' => $row_event['discription'],
					'details' => $row_event['details'],
                    'event_date'=> $row_event['event_date'],
                    'current_date'=> $row_event['curent_date'],
                    'event_pic'=>$row_event['event_pic'],
					'event_time' => $row_event['event_time'],
					'gallery_id' => $event_sql_id2,
'isgallery' => $isgallery,
					'location' => $row_event['location'],
					'date_time' => $date_time,
'event_tag' =>$event_exist
					
					);
			$success = array('status'=> true, "Error" => "your Event",'fetch_event' => $result);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}		

///////////////event_calender////////////////
public function event_calender() {
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
        $event_date=$this->_request['event_date'];
       
		$evn_cal = $this->db->prepare("SELECT * FROM event WHERE event_date='".$event_date."'");
			 $evn_cal->execute();
             $row_evn1 = $evn_cal->fetchALL(PDO::FETCH_ASSOC);
            
				if($evn_cal->rowCount()>0)
			{
                foreach( $row_evn1 as  $row_evn)
                {
			$result[] = array('id' => $row_evn['id'],
					'title' => $row_evn['title'],
                    'discription' => $row_evn['discription'],
                    'event_date' => $row_evn['event_date'],
					'event_time' => $row_evn['event_time']
            		);
                }
		    $success = array('status'=> true, "Error" => "Event Date",'event_calender' => $result  );
			$this->response($this->json($success), 200);
		}    
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
}
//////////////////////
////////news//////////
public function news() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		        $limit=1;
$limit_start=$this->_request['start'];
				
        $news_sql = $this->db->prepare("SELECT * FROM news where flag=0 order by id DESC LIMIT $limit_start , $limit ");

		$news_sql->execute();
				if($news_sql->rowCount()>0)
			{
			$news_fsql = $news_sql->fetchALL(PDO::FETCH_ASSOC);
			foreach($news_fsql as $row_news)
            {
                
                if(!empty($row_news['news_pic'])){
						 $row_news['news_pic'] = $site_url."news/".$row_news['news_pic'];
					}else{
						 $row_news['news_pic'] = "";
					}
					
					
$timestamp=$row_news['news_date'];
$dt=str_replace('-', '', $timestamp);
$exact_trim=$dt;
$datetime = DateTime::createFromFormat('Ymd', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');

$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'year' => $ey,
);
					
					
                
			$result[] = array('id' => $row_news['id'],
					'news_title' => $row_news['news_title'],
					'news_sub_description'=>$row_news['news_sub_description'],
                    'news_details' => $row_news['news_details'],
                    'news_date'=> $row_news['news_date'],
                    'news_pic'=>$row_news['news_pic'],
					'news_location'=>$row_news['news_location'],
					'date_time'=>$date_time
					
					);
            }
                               if(!empty($result))
				{
					 $kkr=$result;
				}
				else
				{
					$kkr=array();
				}
			$success = array('status'=> true, "Error" => "news",'news' => $kkr);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
		///
	
public function fetch_news() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		        $news_id=$this->_request['news_id'];
			$nws_sql_id = $this->db->prepare("SELECT * FROM gallery where event_id='".$news_id."' AND type='2'");
		$nws_sql_id->execute();
		$nws_sql_id1 = $nws_sql_id->fetch(PDO::FETCH_ASSOC);
if(!empty($nws_sql_id1))
		{
		$nws_sql_id2=$nws_sql_id1['id'];	
		}
		else{
			$nws_sql_id2='';
		}
		
				
				
        $news_sql = $this->db->prepare("SELECT * FROM news where id='".$news_id."'");
		$news_sql->execute();
				if($news_sql->rowCount()>0)
			{
			$row_news = $news_sql->fetch(PDO::FETCH_ASSOC);
			
                if(!empty($row_news['news_pic'])){
						 $row_news['news_pic'] = $site_url."news/".$row_news['news_pic'];
					}else{
						 $row_news['news_pic'] = "";
					}
					
									
$timestamp=$row_news['news_date'];
$dt=str_replace('-', '', $timestamp);
$exact_trim=$dt;
$datetime = DateTime::createFromFormat('Ymd', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');

$date_time=array('date' => $ed,
'day' => $edd,
'month' => $em,
'year' => $ey,
);
                
			$result = array('id' => $row_news['id'],
					'news_title' => $row_news['news_title'],
					'news_sub_description'=>$row_news['news_sub_description'],
                    'news_details' => $row_news['news_details'],
                    'news_date'=> $row_news['news_date'],
                    'news_pic'=>$row_news['news_pic'],
					'gallery_id'=>$nws_sql_id2,
					'news_location'=>$row_news['news_location'],
					'date_time'=>$date_time
					);
			$success = array('status'=> true, "Error" => "news",'fetch_news' => $result);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
	
	//////////////


public function inquiry_form(){
		
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		
		 $user_id = $this->_request['user_id'];
		 $name = $this->_request['name'];
		$email = $this->_request['email'];
		$study= $this->_request['study'];
		$address = $this->_request['address'];
		$mobile_no = $this->_request['mobile_no'];
		$query = $this->_request['query'];
        $curent_date = date("Y-m-d");
		
		
		if(!empty($user_id))
		{
		$sql_insert = $this->db->prepare("INSERT into inquiry_form(user_id,name,email,study,address,mobile_no,query,curent_date)
				VALUES(:user_id,:name,:email,:study,:address,:mobile_no,:query,:curent_date)");
				
				$sql_insert->bindParam(":user_id", $user_id, PDO::PARAM_STR);										
                $sql_insert->bindParam(":name", $name, PDO::PARAM_STR);
				$sql_insert->bindParam(":email", $email, PDO::PARAM_STR);
                $sql_insert->bindParam(":study", $study, PDO::PARAM_STR);
				$sql_insert->bindParam("address", $address, PDO::PARAM_STR);
				$sql_insert->bindParam("mobile_no", $mobile_no, PDO::PARAM_STR);
				$sql_insert->bindParam("query", $query, PDO::PARAM_STR);
				$sql_insert->bindParam("curent_date", $curent_date, PDO::PARAM_STR);
                $sql_insert->execute();
             
                $success = array('status'=> true, "Error" => "Thank you your message updated successfully");
                   $this->response($this->json($success), 200);
				   
		}
		else{
			$error = array('status' => false, "Error" => "Try again");
			$this->response($this->json($error), 200);
		}
				 
}

////
public function contact_us(){
		
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		 $select_id = $this->_request['select_id'];
		$subject = $this->_request['subject'];
		$message= $this->_request['message'];
		$login_id = $this->_request['login_id'];
        $date = date("Y-m-d");

		$sql_insert = $this->db->prepare("INSERT into contact_us(admin_id,subject,message,login_id,date)
				VALUES(:admin_id,:subject,:message,:login_id,:date)");
																			
																			
                $sql_insert->bindParam(":admin_id", $select_id, PDO::PARAM_STR);
				$sql_insert->bindParam(":subject", $subject, PDO::PARAM_STR);
                $sql_insert->bindParam(":message", $message, PDO::PARAM_STR);
				$sql_insert->bindParam("login_id", $login_id, PDO::PARAM_STR);
				$sql_insert->bindParam("date", $date, PDO::PARAM_STR);
                $sql_insert->execute();
             
                $success = array('status'=> true, "Error" => "Thank you your message updated successfully");
                   $this->response($this->json($success), 200);
				 
}
///category//////
public function category() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
        $cate_sql = $this->db->prepare("SELECT * FROM category");
		$cate_sql->execute();
			 
				if($cate_sql->rowCount()>0)
			{
			$cate_fet= $cate_sql->fetchALL(PDO::FETCH_ASSOC);
            foreach($cate_fet as $row_category)
            {
			$result[] = array('category_id' => $row_category['category_id'],
			'category' => $row_category['category']
					);
            }
			$success = array('status'=> true, "Error" => "",'category' => $result);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}

///////////////////////gallery//////
public function gallery() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		$limit=1;
				$limit_start=$this->_request['start'];

        $gallery_sql = $this->db->prepare("SELECT * FROM gallery order by id DESC LIMIT $limit_start , $limit");
		$gallery_sql->execute();
			 
				if($gallery_sql->rowCount()>0)
			{
			$gallery_fet = $gallery_sql->fetchALL(PDO::FETCH_ASSOC);
			   
            foreach($gallery_fet as $row_gallery1)
            {
				$id=$row_gallery1['id'];
				$event_id=$row_gallery1['event_id'];
                $type=$row_gallery1['type'];
				
				 $ef_sql = $this->db->prepare("SELECT * FROM event where id='".$event_id."'");
				$ef_sql->execute();
				$efc_sql = $ef_sql->fetch(PDO::FETCH_ASSOC);
                                     if(!empty($efc_sql['event_pic'])){
						 $efc_sql['event_pic'] = $site_url."event/".$efc_sql['event_pic'];
					}else{
						 $efc_sql['event_pic'] = "";
					}

		        $f_sql = $this->db->prepare("SELECT * FROM sub_gallery where gallery_id='".$id."' order by id DESC");
				$f_sql->execute();
				$fc_sql = $f_sql->fetchALL(PDO::FETCH_ASSOC);
                                $src= $f_sql->rowCount();
				
				foreach($fc_sql as $row_gallery)
				{
                if(!empty($row_gallery['gallery_pic'])){
						 $row_gallery['gallery_pic'] = $site_url."gallery/".$row_gallery['gallery_pic'];
					}else{
						 $row_gallery['gallery_pic'] = "";
					}
                    $result[] = array(
					'gallery' => $row_gallery['gallery_pic']
					
					);
                }

                           if(!empty($result))
				{
					 $kkr=$result;
				}
				else
				{
					$kkr=array();
				}


				if($type==1)
				{
				 $ef_sql = $this->db->prepare("SELECT * FROM event where id='".$event_id."'");
				$ef_sql->execute();
				$efc_sql = $ef_sql->fetch(PDO::FETCH_ASSOC);
                                     if(!empty($efc_sql['event_pic'])){
						 $efc_sql['event_pic'] = $site_url."event/".$efc_sql['event_pic'];
					}else{
						 $efc_sql['event_pic'] = "";
					}
					$id = $efc_sql['id'];
					$edate = $efc_sql['event_date'];
					$title = $efc_sql['title'];
					$pic = $efc_sql['event_pic'];
				}
				else if($type==2)
				{
				 $ef_sql = $this->db->prepare("SELECT * FROM news where id='".$event_id."'");
				$ef_sql->execute();
				$efc_sql = $ef_sql->fetch(PDO::FETCH_ASSOC);
                                     if(!empty($efc_sql['news_pic'])){
						 $efc_sql['news_pic'] = $site_url."news/".$efc_sql['news_pic'];
					}else{
						 $efc_sql['news_pic'] = "";
					}
					
					$id = $efc_sql['id'];
					$edate = $efc_sql['news_date'];
					$title = $efc_sql['news_title'];
					$pic = $efc_sql['event_pic'];
				}
				$result1[]= array('id' => $id,
				'event_date' =>$edate,
				'title' =>$title,
				'event_pic' =>$pic,
'total_row' =>$src,
				'gallery_pic' =>$kkr,
					);

					unset($result);
 		}
 			$success = array('status'=> true, "Error" => "your gallery",'gallery' => $result1);
			$this->response($this->json($success), 200);
           }
		else{
			$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
/////

public function fetch_add_to_calendar(){
		
 include_once("common/global.inc.php");
        global $link;
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
			$user_id = $this->_request['user_id'];
			$date = date("Y-m-d");
			$cate_sql = $this->db->prepare("SELECT * FROM add_to_calendar where user_id='".$user_id."' group by event_date");
			$cate_sql->execute();
				if($cate_sql->rowCount()>0)
				{


			$f_calander = $cate_sql->fetchALL(PDO::FETCH_ASSOC);
			foreach($f_calander as $f_calander1)
			{
				$c_event_date[]=$f_calander1['event_date'];
				
			}
			
			$my_date=array_unique($c_event_date);	
//unset($c_event_date);
foreach($my_date as $my_x_date)
{
			$timestamp1=$my_x_date;
			$dt1=str_replace('-', '', $timestamp1);
			$exact_trim1=$dt1;
			$datetime1 = DateTime::createFromFormat('Ymd', $exact_trim1);
			$ed=$datetime1->format('d');
			$edd=$datetime1->format('D');
			$em=$datetime1->format('M');
			$ey=$datetime1->format('Y');
			$date_time1=array('date' => $ed,
			'day' => $edd,
			'month' => $em,
			'year' => $ey,
			);

	
	$my_cate_sql = $this->db->prepare("SELECT * FROM add_to_calendar where user_id='".$user_id."' AND event_date='".$my_x_date."' order by id DESC");
			$my_cate_sql->execute();
			$my_cate_sql1 = $my_cate_sql->fetchALL(PDO::FETCH_ASSOC);
			
			
			foreach($my_cate_sql1 as $row_event)
			{
				$c_event_id=$row_event['event_id'];
     			$event_sql_id = $this->db->prepare("SELECT * FROM gallery where event_id='".$c_event_id."' ");
				$event_sql_id->execute();
				$event_sql_id1 = $event_sql_id->fetch(PDO::FETCH_ASSOC);
				if(!empty($event_sql_id1))
				{
				$event_sql_id2=$event_sql_id1['id'];	
				}
				else{
				$event_sql_id2='';
				}			
				
				$event_sql = $this->db->prepare("SELECT * FROM event where id='".$c_event_id."' ");
		        $event_sql->execute();
			    $row_event = $event_sql->fetch(PDO::FETCH_ASSOC);
                if(!empty($row_event['event_pic'])){
						 $row_event['event_pic'] = $site_url."event/".$row_event['event_pic'];
					}else{
						 $row_event['event_pic'] = "";
					}
					
					
	$timestamp=$row_event['event_date'];
					$dt=str_replace('-', '', $timestamp);
					$event_time=$row_event['event_time'];
					$newDateTime = date('h:i', strtotime($event_time));
					$npm = date('A', strtotime($event_time));
					$tm=str_replace(':', '', $newDateTime);
					$exact_trim=$dt.$tm;
					$datetime = DateTime::createFromFormat('YmdHi', $exact_trim);
					$ed=$datetime->format('d');
					$edd=$datetime->format('D');
					$em=$datetime->format('M');
					$ey=$datetime->format('Y');
					$eh=$datetime->format('H');
					$ei=$datetime->format('i');
					$date_time=array('date' => $ed,
					'day' => $edd,
					'month' => $em,
					'year' => $ey,
					'H' => $eh,
					'I' => $ei,
					'A' => $npm);

			$result1[]= array('event_id' => $row_event['id'],
			'user_id' => $user_id,
					'title' => $row_event['title'],
                    'discription' => $row_event['discription'],
					'details' => $row_event['details'],
                    'event_date'=> $row_event['event_date'],
                    'current_date'=> $row_event['curent_date'],
                    'event_pic'=>$row_event['event_pic'],
					'event_time' => $row_event['event_time'],
					'gallery_id' => $event_sql_id2,
					'location' => $row_event['location']
					//'date_time' => $date_time
				);		
			}
			
			$result[]= array('date_time' => $date_time1,
					'add_event' => $result1
				);		
				unset($result1);	
}


			
				$success = array('status'=> true, "Error" => "Your selected events.",'Responce' => $result);
                $this->response($this->json($success), 200);
                }
				else{
					$error = array('status' => false, "Error" => "No, You have not added any event.",'Responce' => $result[]=array());
			     $this->response($this->json($error), 200);
				}
}
////

public function fetch_gallery() {
              include_once("common/global.inc.php");
        global $link;
            if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
		$limit=1;
				$gallery_id=$this->_request['gallery_id'];
		        $f_sql = $this->db->prepare("SELECT * FROM sub_gallery where gallery_id='".$gallery_id."' order by id DESC");
				$f_sql->execute();
				$fc_sql = $f_sql->fetchALL(PDO::FETCH_ASSOC);
                //$src= $f_sql->rowCount();
				if($f_sql->rowCount()>0)
				{
				foreach($fc_sql as $row_gallery)
				{
                if(!empty($row_gallery['gallery_pic'])){
						 $row_gallery['gallery_pic'] = $site_url."gallery/".$row_gallery['gallery_pic'];
					}else{
						 $row_gallery['gallery_pic'] = "";
					}
                    $result[] = array(
					'gallery' => $row_gallery['gallery_pic']
					);
                }

					if(!empty($result))
					{
					$kkr=$result;
					}
					else
					{
					$kkr=array();
					}


 			$success = array('status'=> true, "Error" => "gallery data",'gallery' => $kkr);
			$this->response($this->json($success), 200);
           }
		else{
			$error = array('status' => false, "Error" => "no data found",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
//////

public function acedmic_calendar() {
              include_once("common/global.inc.php");
        global $link;
                     
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
        $cal_sql = $this->db->prepare("SELECT * FROM acedmic_calendar group by tag");
		$cal_sql->execute();
		    if($cal_sql->rowCount()>0)
			{
			$cal_sql1= $cal_sql->fetchALL(PDO::FETCH_ASSOC);
            foreach($cal_sql1 as $cal_sql11)
            {
				
				$tag_id = $cal_sql11['tag'];
				$exact_tag_id=$tag_id-1;
				
				$cal_ex = $this->db->prepare("SELECT * FROM acedmic_calendar where tag='".$tag_id."'");
				$cal_ex->execute();
				$cal_ex1= $cal_ex->fetchALL(PDO::FETCH_ASSOC);
			

            foreach($cal_ex1 as $cal_ex11)
            {
				$timestamp[]=$cal_ex11['date'];
			}
			
$fff=array_unique($timestamp);
unset($timestamp);
foreach($fff as $cal_ex11)
{
	
	$dt=str_replace('-', '', $cal_ex11);
$exact_trim=$dt;
$datetime = DateTime::createFromFormat('Ymd', $exact_trim);
$ed=$datetime->format('d');
$edd=$datetime->format('D');
$em=$datetime->format('M');
$ey=$datetime->format('Y');


	
	
				$cal_c = $this->db->prepare("SELECT * FROM acedmic_calendar where date='".$cal_ex11."'");
				$cal_c->execute();
				$cal_c1= $cal_c->fetchALL(PDO::FETCH_ASSOC);
				
				foreach($cal_c1 as $cal_c11)
				{
				$result_c[] = array(
				'id' => $cal_c11['id'],
			'name' => $cal_c11['name'],
			'type' => $cal_c11['type'],
			'date' => $cal_c11['date'],
			'time' => $cal_c11['time']
					);
			}
			$result[] =array('date' => $ed,
			'day' => $edd,

			'month' => $em,
			'year' => $ey,
			'event'=>$result_c);
			unset($result_c);
}
			$result1[] = array('month_id' => $exact_tag_id,
			'data' => $result);
			unset($result);
			}
			
			$success = array('status'=> true, "Error" => "All records",'acedmic_calendar' => $result1);
			$this->response($this->json($success), 200);
            }
		else{
			$error = array('status' => false, "Error" => "No records",'Responce' => '');
			$this->response($this->json($error), 200);
		}
		}
////

public function add_to_calendar(){
		
		if ($this->get_request_method() != "POST") {
            $this->response('', 406);
        }
			$user_id = $this->_request['user_id'];
			$event_id = $this->_request['event_id'];
			$option = $this->_request['option'];
			$date = date("Y-m-d");
			
			$cate_sql = $this->db->prepare("SELECT * FROM add_to_calendar where user_id='".$user_id."' AND event_id='".$event_id."'");
					$cate_sql->execute();
					if($cate_sql->rowCount()==0 && $option=='add')
					{


$s_e_sql = $this->db->prepare("SELECT * FROM event where id='".$event_id."'");
					    $s_e_sql->execute();
						$s_e_sql1 = $s_e_sql->fetch(PDO::FETCH_ASSOC);
						$e_date=$s_e_sql1['event_date'];


		        $sql_insert = $this->db->prepare("INSERT into add_to_calendar(event_id,user_id,curent_date,event_date)
				VALUES(:event_id,:user_id,:curent_date,:event_date)");
                $sql_insert->bindParam(":event_id", $event_id, PDO::PARAM_STR);
				$sql_insert->bindParam(":user_id", $user_id, PDO::PARAM_STR);
				$sql_insert->bindParam("curent_date", $date, PDO::PARAM_STR);
$sql_insert->bindParam("event_date", $e_date, PDO::PARAM_STR);
                $sql_insert->execute();
				$success = array('status'=> true, "Error" => "Event added successfully", "isadded" => true);
                $this->response($this->json($success), 200);
				}
				else if($cate_sql->rowCount()==1 && $option=='remove')
				{
				$sql_d = $this->db->prepare("DELETE from add_to_calendar where user_id='".$user_id."' AND event_id='".$event_id."' ");
				$sql_d->execute();
				$success = array('status'=> true, "Error" => "Event remove successfully", "isadded" => false);
                $this->response($this->json($success), 200);
				}
				else{
					$error = array('status' => false, "Error" => "Try again",'Responce' => '');
			     $this->response($this->json($error), 200);
				}

}
///////////////////////////////////////////		
    /*
     *  Encode array into JSON
     */
    private function json($data) {

        if (is_array($data)) {
         
            return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP );
        }
    }
}
// Initiiate Library    
$api = new API;
$api->processApi();
?>